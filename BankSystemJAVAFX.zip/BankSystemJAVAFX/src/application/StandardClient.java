package application;

public class StandardClient extends Client {

	public StandardClient(String username, String password) {
		super(username, password);
	}

}
