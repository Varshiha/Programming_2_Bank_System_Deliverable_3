package application;
import java.time.LocalDate;
import java.util.ArrayList;

public abstract class Account implements Maintainable, InterestBearing{
	protected String accountNo;
	protected double balance;
	protected String openDate; 
	protected int clientID;
	protected String type;
	protected String lastFeeApplied;
	protected String lastFeeAppliedInterest;
	protected ArrayList<Transaction> transactions;
	
	/*
	 Constructor for new accounts being created
	 */
	public Account(Client client) {
		this.balance = 0;
		this.openDate = LocalDate.now().toString();
		this.clientID = client.getClientID();
		this.transactions = new ArrayList<>();
	}
	/*
	 ===========================================================================================================
	                                   CALCULATING
	 ===========================================================================================================
	 */
	public void deposit(double amount) {
		if(amount <= 0) {
			throw new IllegalArgumentException("Amount must be greater than 0");
		}
		balance += amount;
		addTransaction(new Transaction("DEPOSIT", amount, accountNo, "Deposit"));
	}
	
	public void deposit(double amount, String description) {
		if(amount <= 0) {
			throw new IllegalArgumentException("Amount must be greater than 0");
		}
		balance += amount;
		addTransaction(new Transaction("DEPOSIT", amount, accountNo, description));
	}
	
	public void withdraw(double amount) throws InsufficientFundsException, IllegalArgumentException{
		if(amount <= 0) {
			throw new IllegalArgumentException("Amount must be greater than 0");
		}
		if(amount > balance) {
			throw new InsufficientFundsException("Amount withdrawn must be less than the balance");
		}
		balance -= amount;
		addTransaction(new Transaction("WITHDRAW", amount, accountNo, "Withdrawal"));
	}

	public void addTransaction(Transaction t) {
		if(t != null) {
			transactions.add(t);
		}
	}
	
	/*
	 ===========================================================================================================
	                                   DISPLAY INFORAMATION
	 ===========================================================================================================
	 */
	public String getFullInfo() {
		return "Account Type: " + type + 
			   "\nAccountNo: " + accountNo + 
			   "\nBalance: " + balance + 
			    "\nOpenDate: " + openDate +
			    "\nClient: " + clientID;
	}
	
	@Override
	public String toString() {
		return accountNo + " : $" + balance;
	}
	
	/*
	 ===========================================================================================================
	                                   GETTERS
	 ===========================================================================================================
	 */
	public String getType() {
		return type;}
	
	public String getAccountNo() {
		return accountNo;}

	public double getBalance() {
		return balance;}

	public String getOpenDate() {
		return openDate;}

	public int getClientID() {
		return clientID;}

	public ArrayList<Transaction> getTransactions() {
		return transactions;}
	
	/*
	 ===========================================================================================================
	                                   SETTERS
	 ===========================================================================================================
	 */
	public void setLastFeeApplied(String lastFeeApplied) {
		this.lastFeeApplied = lastFeeApplied;}
	
	public void setLastFeeAppliedInterest(String lastFeeAppliedInterest) {
		this.lastFeeAppliedInterest = lastFeeAppliedInterest;}
	
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;}
	
	public void setBalance(double balance) {
		this.balance = balance;}
	
	public void setOpenDate(String openDate) {
		this.openDate = openDate;}
	
	public void setClientID(int clientID) {
		this.clientID = clientID;}
	
	public void applyInterest(Client client) {}
	public void applyMonthlyFee(Client client){}

	

}
