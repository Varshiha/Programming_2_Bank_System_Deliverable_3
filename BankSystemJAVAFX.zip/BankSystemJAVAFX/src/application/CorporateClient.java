package application;

public class CorporateClient extends PremiumClient{
	

	public CorporateClient(String username, String password) {
		super(username, password);
		this.type = "Corporate";
	}

}
