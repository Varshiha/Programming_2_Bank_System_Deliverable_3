package application;

import java.util.ArrayList;

public class GetCurrentClient {
	public static String currentUsername;
	public static int currentClientID;
	public static Client currentClient;
	public static ArrayList<Client> clients;
	public static ArrayList<Account> accounts;

}
