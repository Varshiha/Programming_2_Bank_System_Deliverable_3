package application;
import java.time.LocalDate;

public class Transaction {
	
	private int transactionID;
	private String type;
	private double amount;
	private String date;
	private String accountNo;
	private String description;
	private static int counter = 1;
	
	public Transaction(String type, double amount, String accountNo, String description) {
		this.transactionID = counter++;
		this.type = type;
		this.amount = amount;
		this.date = LocalDate.now().toString();
		this.accountNo = accountNo;
		this.description = description;
	}
	
	public Transaction(String type, double amount, String accountNo, String description, String date) {
		this.transactionID = counter++;
		this.type = type;
		this.amount = amount;
		this.date = date;
		this.accountNo = accountNo;
		this.description = description;
	}
	
	
	public static void setCounter(int value) {
		counter = value;
	}

	/*
	 ===========================================================================================================
	                               GETTERS
	 ===========================================================================================================
	 */
	public int getTransactionID() {
		return transactionID;
	}

	public String getType() {
		return type;
	}

	public double getAmount() {
		return amount;
	}

	public String getDate() {
		return date;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public String getDescription() {
		return description;
	}
	/*
	 ===========================================================================================================
	                                INFORMATION
	 ===========================================================================================================
	 */
	@Override
	public String toString() {
		return "TransactionID: " + transactionID + 
				"\nType: " + type + 
				"\nAmount: " + amount + 
				"\nDate: " + date + 
				"\nAccountNo: " + accountNo + 
				"\nDescription: " + description;
	}
	
	
	

}
