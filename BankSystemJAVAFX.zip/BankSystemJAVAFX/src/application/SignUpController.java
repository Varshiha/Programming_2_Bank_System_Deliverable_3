package application;

import java.io.IOException;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
public class SignUpController {
	@FXML
	private TextField usernameField;
	@FXML
	private PasswordField passwordField;
	@FXML
	private PasswordField confirmField;
	@FXML
	private AnchorPane formBox;
	@FXML
	private Label messageLabel;
	@FXML
	private Button mainButton;
	
	private String selectType;
	
	@FXML
	private void initialize() throws IOException{
		formBox.setVisible(false);
		formBox.setManaged(false);
	}
	/*
	 ===========================================================================================================
	                                 MAIN SCREEN
	 ===========================================================================================================
	 */
	@FXML
	private void goBackMain(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("Welcome.fxml"));
		Scene scene = new Scene(root,1000,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		stage.setScene(scene);
		stage.show();
	}
	/*
	 ===========================================================================================================
	                                 SIGN UP ACTIONS
	 ===========================================================================================================
	 */
	
	@FXML
	private void setIndividual(ActionEvent event) throws IOException{
		selectType = "Individual";
		showForm();
	}
	@FXML
	private void setStudent(ActionEvent event) throws IOException{
		selectType = "Student";
		showForm();
	}
	@FXML
	private void setCorporate(ActionEvent event) throws IOException {
		selectType = "Corporate";
		showForm();
	}
	@FXML
	private void setVIP(ActionEvent event) throws IOException {
		selectType = "VIP";
		showForm();
	}
	@FXML
	private void check(ActionEvent event) throws IOException {
		String user = usernameField.getText();
		String pass = passwordField.getText();
		String confirm = confirmField.getText();
		System.out.println(pass);
		System.out.println(confirm);
		
		if(user == null || pass == null || confirm == null || 
				user.isEmpty() || pass.isEmpty() || confirm.isEmpty()) {
			messageLabel.setText("Fill all the fields");
			return;
		}
		
		if(!pass.equals(confirm)) {
			messageLabel.setText("Passwords do not match");
			return;
		}
		
		ArrayList<Client> clients = FileManager.loadClients();
		boolean match = false;
		
		for(Client c : clients) {
			if(c.getUsername().equals(user)) {
				match = true;
				break;
			}
		}
		if(match){
			messageLabel.setText("Username already exists.");
		}else {
		switch(selectType) {
		case "Individual" :
			clients.add(new IndividualClient(user, pass));
			break;
		case "Student" :
			clients.add(new StudentClient(user, pass));
			break;
		case "Corporate" :
			clients.add(new CorporateClient(user, pass));
			break;
		case "VIP" :
			clients.add(new VIPClient(user, pass));
			break;
		}
		    FileManager.saveClients(clients);
			messageLabel.setText("Client Account created succesfully");
		}
	}
	
	private void showForm() throws IOException {
		formBox.setVisible(true);
		formBox.setManaged(true);
		
	}
	
	/*
	 ===========================================================================================================
	                                  LOGIN SCREEN
	 ===========================================================================================================
	 */
	
	@FXML
	private void goBackLogin(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
		Scene scene = new Scene(root,1000,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		stage.setScene(scene);
		stage.show();
	}

}
