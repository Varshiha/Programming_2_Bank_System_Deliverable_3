package application;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class DriverTest {

	@Test
	void testDeposit() {
		StudentClient joey = new StudentClient("Joey_Tribiani", "wearclothes");
		ChequingAccount account = new ChequingAccount(joey);
		joey.addAccount(account);
		joey.deposit(account.getAccountNo(), 2000);
		joey.deposit(account.getAccountNo(), 2000);
		assertEquals(4000, account.getBalance(), "Joey's balance should be 2000+2000");
	}

	@Test
	void testWithdraw() throws InsufficientFundsException {
		VIPClient chandler = new VIPClient("Chandler_Bing", "favourite");
		ChequingAccount account = new ChequingAccount(chandler);
		chandler.addAccount(account);
		chandler.deposit(account.getAccountNo(), 6000);
		chandler.withdraw(account.getAccountNo(), 300);
		assertEquals(5700, account.getBalance(), "Chandler's balance should be 6000-300");
	}

	@Test
	void testTransfer() throws Exception {
		IndividualClient monica = new IndividualClient("Monica", "sopretty");
		ChequingAccount account1 = new ChequingAccount(monica);
		monica.addAccount(account1);
		SavingsAccount account2 = new SavingsAccount(monica);
		monica.addAccount(account2);
		monica.deposit(account1.getAccountNo(), 60000);
		monica.deposit(account2.getAccountNo(), 40000);
		monica.transfer(account1.getAccountNo(), account2.getAccountNo(), 1000);
		assertEquals(59000, account1.getBalance(), "Monica's Chequing balance should be 59000");
		assertEquals(41000, account2.getBalance(), "Monica's Savings balance should be 41000");
	}
	
	@Test
	void testApplyMonthly() throws Exception {
		CorporateClient rachel = new CorporateClient("Rachel", "ralphlauren");
		ChequingAccount account = new ChequingAccount(rachel, "2026-03-09");
		rachel.addAccount(account);
		rachel.deposit(account.getAccountNo(), 50);
		account.applyMonthlyFee(rachel);
		assertEquals(30, account.getBalance(), "Rachel's Chequing balance should be 30 after 2 monthly fees(50-10-10)");
	}
	
	@Test
	void testApplyInterest() throws Exception {
		VIPClient phoebe = new VIPClient("Phoebe", "smellycat");
		SavingsAccount account = new SavingsAccount(phoebe, "2025-05-09");
		phoebe.addAccount(account);
		phoebe.deposit(account.getAccountNo(), 300);
		account.applyInterest(phoebe);
		assertEquals(309, account.getBalance(), "Pheobe's Savings balance should be 309 after interest for vip client (2+1) interest and 300+300*3");
	}
	
	

}
