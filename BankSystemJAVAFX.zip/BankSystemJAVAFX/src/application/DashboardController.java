package application;

import java.io.IOException;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class DashboardController {
	/*
	 ===========================================================================================================
	                                   FIELDS
	 ===========================================================================================================
	 */
	private Account selectedAccount;
	@FXML private Label welcomeName;
	@FXML private Button close;
	@FXML private Button logout;
	@FXML private AnchorPane createAccountPane;
	@FXML private Button closeCreateAccount;
	@FXML private ListView<Account> accountsList;
	@FXML private TextArea accountInfo;
	@FXML private ListView<Transaction> transactionsList;
	@FXML private TextField amountField;
	@FXML private TextField reasonField;
	@FXML private ComboBox<Account> fromAccountCombo;
	@FXML private ComboBox<Account> toAccountCombo;
	@FXML private TextField amountTransfer;
	@FXML private AnchorPane transferPane;
	
	 public void initialize() throws IOException{
			    welcomeName.setText("Welcome, " + GetCurrentClient.currentUsername);
			    refreshAccount();	    
	 }	
	 public void refreshAccount() throws IOException {
		 System.out.println("In refresh account");
		 for(Account acc : GetCurrentClient.accounts) {
				if(acc.getClientID() == GetCurrentClient.currentClientID) {
					 acc.applyMonthlyFee(GetCurrentClient.currentClient);
					 acc.applyInterest(GetCurrentClient.currentClient);
				}
			}
		 FileManager.saveClients(GetCurrentClient.clients);
		 FileManager.saveAccounts(GetCurrentClient.accounts);
		 FileManager.saveTransactions(GetCurrentClient.accounts);
	 }
	 
	 /*
	 ===========================================================================================================
	                                   VIEW ACCOUNTS - ACCOUNTS AND TRANSACTIONS
	 ===========================================================================================================
	 */
	@FXML
	public void goToAccounts() throws IOException {
		accountsList.getItems().clear();
		for(Account acc : GetCurrentClient.accounts) {
			if(acc.getClientID() == GetCurrentClient.currentClientID) {
				accountsList.getItems().add(acc);
			}
		}
		
	}
	@FXML
	private void handleAccountClick(MouseEvent event) {
		accountInfo.setVisible(true);
		transactionsList.setVisible(true);
		close.setVisible(true);
		selectedAccount = accountsList.getSelectionModel().getSelectedItem();
		if(selectedAccount == null) return;
		accountInfo.setText(selectedAccount.getFullInfo());
		System.out.println(selectedAccount.openDate);
		transactionsList.getItems().setAll(selectedAccount.getTransactions());
	}
	/*
	 ===========================================================================================================
	                                   DEPOSIT
	 ===========================================================================================================
	 */
	@FXML
	public void handleDeposit(){
		try {
			if(amountField.getText() == null) {
				throw new IllegalArgumentException("Choose an account to deposit in or money must be more than 0.");
			}
			double amount = Double.parseDouble(amountField.getText());
			if(selectedAccount == null || amount <= 0) throw new Exception("Choose an account to deposit in or money must be more than 0.");

			String reason = reasonField.getText();
			if(reason == null || reason.isBlank()) {
				GetCurrentClient.currentClient.deposit(selectedAccount.getAccountNo(),amount);
			}else {
				selectedAccount.deposit(amount, reason);
			}
			amountField.clear();
			reasonField.clear();
			update();
			
		}catch (Exception e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Deposit Issue");
			alert.setHeaderText(null);
			alert.setContentText(e.getMessage()); 
			alert.showAndWait();
		}
	}
	/*
	 ===========================================================================================================
	                                   WITHDRAW
	 ===========================================================================================================
	 */
	
	@FXML
	public void handleWithdraw() throws IOException {
        try {
			
			double amount = Double.parseDouble(amountField.getText());
			if(selectedAccount == null || amount <= 0) throw new Exception("Choose an account to deposit in or money must be more than 0.");
			String reason = reasonField.getText();
			if(reason == null || reason.isBlank()) {
				reason = "Withdraw";}
			
			GetCurrentClient.currentClient.withdraw(selectedAccount.getAccountNo(), amount);
			amountField.clear();
			reasonField.clear();
			update();
			
        } catch (InsufficientFundsException e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Insufficient funds");
			alert.setHeaderText(null);
			alert.setContentText(e.getMessage()); 
			alert.showAndWait();
			
        } catch (IllegalArgumentException e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Amount Issue");
			alert.setHeaderText(null);
			alert.setContentText(e.getMessage()); 
			alert.showAndWait();
			
        } catch(Exception e) {
        	    Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Account Error");
			alert.setHeaderText(null);
			alert.setContentText(e.getMessage()); 
			alert.showAndWait();
        }
	}
	/*
	 ===========================================================================================================
	                                  TRANSACTION CLOSE BUTTON
	 ===========================================================================================================
	 */
	@FXML
	public void closeAccounts() {
		accountInfo.setVisible(false);
		transactionsList.setVisible(false);
		close.setVisible(false);
	}
	/*
	 ===========================================================================================================
	                                   TRANSFER
	 ===========================================================================================================
	 */
	@FXML
	public void handleConfirmTransfer(ActionEvent e){
		try {
			Account from = fromAccountCombo.getValue();
			Account to = toAccountCombo.getValue();
			double amount = Double.parseDouble(amountTransfer.getText());
			if(from == to) {
				throw new IllegalArgumentException("Cannot transfer to the same account");
			}
			
			GetCurrentClient.currentClient.transfer(from.getAccountNo(), to.getAccountNo(), amount);
			transferPane.setVisible(false);
			FileManager.saveClients(GetCurrentClient.clients);
			FileManager.saveAccounts(GetCurrentClient.accounts);
			FileManager.saveTransactions(GetCurrentClient.accounts);
			goToAccounts();
			
		}catch (InvestmentLockException lock) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Investment Lock Exception");
			alert.setHeaderText(null);
			alert.setContentText(lock.getMessage()); 
			alert.showAndWait();
		}catch (Exception ex) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Transfer Error");
			alert.setHeaderText(null);
			alert.setContentText(ex.getMessage()); 
			alert.showAndWait();
		}
	} 
	
	@FXML
	private void closeTranserPane() {
		transferPane.setVisible(false);
		amountTransfer.clear();
		fromAccountCombo.getSelectionModel().clearSelection();
		toAccountCombo.getSelectionModel().clearSelection();
	}
	
	@FXML
	private void openTransferPane(ActionEvent e) {
		transferPane.setVisible(true);
		fromAccountCombo.getItems().clear();
		toAccountCombo.getItems().clear();
		
		
		for(Account acc : GetCurrentClient.accounts) {
			if(acc.getClientID() == GetCurrentClient.currentClientID) {
				fromAccountCombo.getItems().add(acc);
				toAccountCombo.getItems().add(acc);
			}
		}
		
	}
	/*
	 ===========================================================================================================
	                                   REFRESH AFTER BALANCE CHANGE
	 ===========================================================================================================
	 */
	
	public void update() throws IOException {
		FileManager.saveClients(GetCurrentClient.clients);
		FileManager.saveAccounts(GetCurrentClient.accounts);
		FileManager.saveTransactions(GetCurrentClient.accounts);
		goToAccounts();
		accountInfo.setText(selectedAccount.getFullInfo());
		transactionsList.getItems().setAll(selectedAccount.getTransactions());
	}
	
	/*
	 ===========================================================================================================
	                                   CREATE ACCOUNT
	 ===========================================================================================================
	 */
	@FXML
	public void goToCreateAccount() {
		createAccountPane.setVisible(true);
	}
	
	@FXML
	public void closeCreate(ActionEvent event) {
		createAccountPane.setVisible(false);
	}
	
	@FXML
	private void createAccount(ActionEvent event) {
		try {
			Button clickedButton = (Button) event.getSource();
		    String id = clickedButton.getId();
		
		    Client client =  GetCurrentClient.currentClient;
		
		    Account newAccount = null;
		
			newAccount = client.openAccount(id);

			if(newAccount != null) {
				client.accounts.add(newAccount);
				GetCurrentClient.accounts.add(newAccount);
			}
			
			FileManager.saveAccounts(GetCurrentClient.accounts);
			goToAccounts();
			createAccountPane.setVisible(false);
		} catch (MissingChequingAccountException e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Account Error");
			alert.setHeaderText(null);
			alert.setContentText(e.getMessage()); 
			alert.showAndWait();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/*
	 ===========================================================================================================
	                                   LOGOUT
	 ===========================================================================================================
	 */
	@FXML
	public void logout(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
		Scene scene = new Scene(root,1000,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		stage.setScene(scene);
		stage.show();
	}

}
