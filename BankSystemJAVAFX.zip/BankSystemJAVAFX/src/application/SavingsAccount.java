package application;

import java.time.LocalDate;

public class SavingsAccount extends Account implements Maintainable, InterestBearing{

	private double interestRate = 0.02;
	protected static int counter = 100;
	
	public SavingsAccount(Client client) {
		super(client);
		this.accountNo = "SAV"+ counter;
		counter = counter+15;
		this.type = "Savings";
	}
	public SavingsAccount(Client client, String openDate) {
		super(client);
		this.accountNo = "SAV"+ counter;
		counter = counter+15;
		this.openDate = openDate;
		this.type = "Savings";
	}
	
	/*
	 ===========================================================================================================
	                                  Monthly Fee
	 ===========================================================================================================
	 */
	@Override
	public void applyMonthlyFee(Client client){
		if(client instanceof StudentClient || client instanceof VIPClient) {
			return;
		}else {
			if(lastFeeApplied == null) {
				lastFeeApplied = openDate;
			}
			LocalDate last = LocalDate.parse(lastFeeApplied);
			LocalDate today = LocalDate.now();
			
			while(last.plusMonths(1).isBefore(today) || last.plusMonths(1).isEqual(today)) {
				last = last.plusMonths(1);
				balance -= 10;
				addTransaction(new Transaction("Monthly Fee", 10, accountNo, "Fee applied", last.toString()));
				
			}
			lastFeeApplied = last.toString();
		}	
	}
	/*
	 ===========================================================================================================
	                                 INTEREST
	 ===========================================================================================================
	 */
	@Override
	public void applyInterest(Client client) {
		if(lastFeeAppliedInterest == null) {
			lastFeeAppliedInterest = openDate;
		}
		LocalDate lastInterest = LocalDate.parse(lastFeeAppliedInterest);
		LocalDate today = LocalDate.now();
		
		while(lastInterest.plusYears(1).isBefore(today) || lastInterest.plusYears(1).isEqual(today)) {
			lastInterest = lastInterest.plusYears(1);
			
			
			double interest = getBalance()*interestRate;
			System.out.println(interest);

			if(client instanceof VIPClient) {
				VIPClient vip = (VIPClient) client;
				interest = interest + (getBalance()*vip.getBonusInterest());
				System.out.println(interest);
			}
			balance += interest;
			System.out.println(interest);

			addTransaction(new Transaction("Interest", interest, accountNo, "Interest applied", lastInterest.toString()));
		}
		lastFeeAppliedInterest = lastInterest.toString();

		}

}
