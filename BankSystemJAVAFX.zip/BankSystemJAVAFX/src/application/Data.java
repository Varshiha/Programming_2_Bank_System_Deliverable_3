package application;
import java.util.ArrayList;

public class Data {
	
	public static ArrayList<Client> createClients(){
		ArrayList<Client> clients = new ArrayList<>();
		clients.add(new IndividualClient("lisamanoban", "lloud1997*"));
		clients.add(new IndividualClient("jenniekim", "ruby199601"));
		clients.add(new CorporateClient("sooya", "veronicarabbitkim"));
		clients.add(new VIPClient("rosie", "hank199702"));
		return clients;
	}
	
	public static ArrayList<Account> createAccounts(ArrayList<Client> clients) throws InsufficientFundsException{
		ArrayList<Account> accounts = new ArrayList<>();
		//Client Lisa
		accounts.add(new ChequingAccount(clients.get(0), "2025-09-09"));
		clients.get(0).addAccount(accounts.get(0));
		accounts.get(0).deposit(100);
		
		accounts.add(new SavingsAccount(clients.get(0), "2025-05-08"));
		clients.get(0).addAccount(accounts.get(1));
		accounts.get(1).deposit(200);
		
		accounts.add(new InvestmentAccount(clients.get(0), "2026-03-09"));
		clients.get(0).addAccount(accounts.get(2));
		accounts.get(2).deposit(300);
		
		//Client Jennie
		accounts.add(new ChequingAccount(clients.get(1), "2026-02-09"));
		clients.get(1).addAccount(accounts.get(3));
		accounts.get(3).deposit(2000);
		
		//Client Jisoo
		accounts.add(new ChequingAccount(clients.get(2),"2026-02-09"));
		clients.get(2).addAccount(accounts.get(4));
		accounts.get(4).deposit(400);
		accounts.add(new InvestmentAccount(clients.get(2), "2024-02-08"));
		clients.get(2).addAccount(accounts.get(5));
		accounts.get(5).deposit(500);
		
		//Client Rose
		
		accounts.add(new ChequingAccount(clients.get(3)));
		clients.get(3).addAccount(accounts.get(6));
		accounts.get(6).deposit(10000);
		
		accounts.add(new SavingsAccount(clients.get(3)));
		clients.get(3).addAccount(accounts.get(7));
		accounts.get(7).deposit(500);
		
		accounts.add(new InvestmentAccount(clients.get(3)));
		clients.get(3).addAccount(accounts.get(8));
		accounts.get(8).deposit(15000);
		
		accounts.get(7).withdraw(200);

		return accounts;
	}
	 public static void main(String[] args) throws Exception {
		 ArrayList<Client> clients = createClients();
		 ArrayList<Account> accounts = createAccounts(clients);
		 FileManager.saveClients(clients);
		 FileManager.saveAccounts(accounts);
		 FileManager.saveTransactions(accounts);
	 }
}
