package application;
import java.time.LocalDate;

public class InvestmentAccount extends Account implements Maintainable, InterestBearing{

	private double interestRate = 0.05;
	protected static int counter = 100;
	/*
	 Constructor for new clients accounts
	 */
	public InvestmentAccount(Client client) {
		super(client);
		this.accountNo = "INV"+ counter;
		counter = counter+15;
		this.type = "Investment";
	}
	/*
	 Constructor for clients accounts when clients are loaded so that open date does not get overwritten
	 */
	public InvestmentAccount(Client client, String openDate) {
		super(client);
		this.accountNo = "INV"+ counter;
		counter = counter+15;
		this.openDate = openDate;
		this.type = "Investment";
	}
	
	@Override
	public void withdraw(double amount) {
		throw new UnsupportedOperationException("Direct withdrawals from an Investment account are forbidden.");
	}

	public void transferToChequing(ChequingAccount accountNo, double amount) throws InvestmentLockException, InsufficientFundsException {
		LocalDate temp = LocalDate.parse(openDate);
		LocalDate date = LocalDate.now();
		if(temp.isBefore(date.minusYears(1)) == false) {
			throw new InvestmentLockException("Transfer not successfull because Investment account has not been open for more than 1 year.");
		}
		super.withdraw(amount);
		accountNo.deposit(amount, "Deposited from investment");
	}
	/*
	 ===========================================================================================================
	                                  Monthly Fee
	 ===========================================================================================================
	 */
	@Override
	public void applyMonthlyFee(Client client){
		if(client instanceof StudentClient || client instanceof VIPClient) {
			return;
		}else {
			if(lastFeeApplied == null) {
				lastFeeApplied = openDate;
			}
			LocalDate last = LocalDate.parse(lastFeeApplied);
			LocalDate today = LocalDate.now();
			
			while(last.plusMonths(1).isBefore(today) || last.plusMonths(1).isEqual(today)) {
				last = last.plusMonths(1);
				balance -= 10;
				addTransaction(new Transaction("Monthly Fee", 10, accountNo, "Fee applied", last.toString()));
				
			}

			lastFeeApplied = last.toString();
		}
		
		
	}

	/*
	 ===========================================================================================================
	                                  INTEREST
	 ===========================================================================================================
	 */
	@Override
	public void applyInterest(Client client) {
		if(lastFeeAppliedInterest == null) {
			lastFeeAppliedInterest = openDate;
		}
		LocalDate lastInterest = LocalDate.parse(lastFeeAppliedInterest);
		LocalDate today = LocalDate.now();
		
		while(lastInterest.plusYears(1).isBefore(today) || lastInterest.plusYears(1).isEqual(today)) {
			lastInterest = lastInterest.plusYears(1);
			
			
			double interest = getBalance()*interestRate;
			System.out.println(interest);

			if(client instanceof VIPClient) {
				VIPClient vip = (VIPClient) client;
				interest = interest + (getBalance()*vip.getBonusInterest());
				System.out.println(interest);
			}
			balance += interest;
			System.out.println(interest);

			addTransaction(new Transaction("Interest", interest, accountNo, "Interest applied", lastInterest.toString()));
		}
		lastFeeAppliedInterest = lastInterest.toString();

			
		}
	}

