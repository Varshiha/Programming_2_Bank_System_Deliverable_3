package application;

import java.time.LocalDate;

public class ChequingAccount extends Account implements Maintainable{

	protected static int counter = 100;
	/*
	 Constructor for new clients accounts
	 */
	public ChequingAccount(Client client) {
		super(client);
		this.accountNo = "CHE"+ counter;
		counter = counter+15;
		this.type = "Chequing";
	}
	/*
	 Constructor for clients accounts when clients are loaded so that open date does not get overwritten
	 */
	public ChequingAccount(Client client, String openDate) {
		super(client);
		this.accountNo = "CHE"+ counter;
		counter = counter+15;
		this.openDate = openDate;
		this.type = "Chequing";
	}
	/*
	 ===========================================================================================================
	                                  Monthly Fee
	 ===========================================================================================================
	 */
	@Override
	public void applyMonthlyFee(Client client){
		if(client instanceof StudentClient || client instanceof VIPClient) {
			return;
		}else {
			if(lastFeeApplied == null) {
				lastFeeApplied = openDate;
			}
			LocalDate last = LocalDate.parse(lastFeeApplied);
			LocalDate today = LocalDate.now();
			while(last.plusMonths(1).isBefore(today) || last.plusMonths(1).isEqual(today)) {
				last = last.plusMonths(1);
				balance -= 10;
				addTransaction(new Transaction("Monthly Fee", 10, accountNo, "Fee applied", last.toString()));
			}
			lastFeeApplied = last.toString();
		}
	}
}
