package application;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.lang.reflect.Type;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

public class FileManager {
	
	public static ArrayList<Client> clients;
	
	public static void saveClients(ArrayList<Client> clients) throws IOException {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		FileWriter writer = new FileWriter("clients.json", false);
	    gson.toJson(clients, writer);
	    writer.close();
	}
	
	public static ArrayList<Client> loadClients() throws IOException {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		FileReader reader = new FileReader("clients.json");
		
		Type listType = new TypeToken<ArrayList<JsonObject>>() {}.getType();
		ArrayList<JsonObject> tempClients = gson.fromJson(reader,listType);
		
		reader.close();
		
		clients = new ArrayList<>();
		
		if(tempClients == null) {
			return clients;
		}
		for(JsonObject c : tempClients) {
			
			int clientID = c.get("clientID").getAsInt();
			String username = c.get("username").getAsString();
			String password = c.get("password").getAsString();
			String type = c.get("type").getAsString();;
			
			Client realClient = null;
			
			if(type.equalsIgnoreCase("Student")) {
				realClient = new StudentClient(username, password);
			}else if(type.equalsIgnoreCase("Individual")) {
				realClient = new IndividualClient(username, password);
			}else if(type.equalsIgnoreCase("Corporate")) {
				realClient = new CorporateClient(username, password);
			}else if(type.equalsIgnoreCase("VIP")) {
				realClient = new VIPClient(username, password);
			}
			if(realClient != null) {
				realClient.setClientID(clientID);
				clients.add(realClient);
			}
		}
		 return clients;
	    
	}
	
	public static void saveAccounts(ArrayList<Account> accounts) throws IOException {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		FileWriter writer = new FileWriter("accounts.json");
	    gson.toJson(accounts, writer);
	    writer.close();
	}
	
	public static ArrayList<Account> loadAccounts(ArrayList<Client> clients) throws IOException {
		
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		FileReader reader = new FileReader("accounts.json");
		
		Type listType = new TypeToken<ArrayList<JsonObject>>() {}.getType();
		ArrayList<JsonObject> tempAccounts = gson.fromJson(reader,listType);
		
		reader.close();
		
		ArrayList<Account> accounts = new ArrayList<>();
		
		if(tempAccounts == null) {
			return accounts;
		}
		
		for(JsonObject a : tempAccounts) {
			
			String type = a.get("type").getAsString();
			String accountNo = a.get("accountNo").getAsString();
			double balance = a.get("balance").getAsDouble();
			String date = a.get("openDate").getAsString();
			int clientID = a.get("clientID").getAsInt();
			String lastFeeApplied;
			if(a.has("lastFeeApplied") && !a.isJsonNull()) {
				lastFeeApplied = a.get("lastFeeApplied").getAsString();
			}else {
				lastFeeApplied = null;
			}
			
			String lastFeeAppliedInterest;
			if(a.has("lastFeeAppliedInterest") && !a.isJsonNull()) {
				lastFeeAppliedInterest = a.get("lastFeeAppliedInterest").getAsString();
			}else {
				lastFeeAppliedInterest = null;
			}
			
			Client owner = null;
			
			for(Client c : clients) {
				if(clientID == c.getClientID()) {
					owner = c;
					break;
				}
			}
			
			Account realAccount = null;
			
			if(type.equalsIgnoreCase("Savings")) {
				realAccount = new SavingsAccount(owner, date);
			}else if(type.equalsIgnoreCase("Chequing")) {
				realAccount = new ChequingAccount(owner, date);
			}else if(type.equalsIgnoreCase("Investment")) {
				realAccount = new InvestmentAccount(owner, date);
			}
			
			if(realAccount != null && owner != null) {
				realAccount.setAccountNo(accountNo);
				//realAccount.setOpenDate(date);
				realAccount.setBalance(balance);
				realAccount.setLastFeeApplied(lastFeeApplied);
				realAccount.setLastFeeAppliedInterest(lastFeeAppliedInterest);
				accounts.add(realAccount);
			}
			
		}
		
		for(Client c : FileManager.clients) {
			ArrayList<Account> link = new ArrayList<>();
			for(Account a : accounts) {
				if(a.getClientID()== c.getClientID()) {
					link.add(a);
				}
				
			}
			
			c.setAccounts(link);
		}
		 
		 return accounts;
	    
	}
	
	public static void saveTransactions(ArrayList<Account> accounts) throws IOException {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		ArrayList<Transaction> transactions = new ArrayList<>();
		
		for(Account a : accounts) {
			transactions.addAll(a.getTransactions());
		}
		
		FileWriter writer = new FileWriter("transactions.json");
		
		gson.toJson(transactions, writer);
		writer.close();
	}
	
	public static void loadTransactions(ArrayList<Account> accounts) throws IOException {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		FileReader reader = new FileReader("transactions.json");
		Type listType = new TypeToken<ArrayList<Transaction>>() {}.getType();
		ArrayList<Transaction> transactions = gson.fromJson(reader, listType);
		reader.close();
		
		if(transactions == null) {
			return;
		}
		
		for(Transaction t : transactions) {
			String accountNo = t.getAccountNo();
			
			Account owner = null;
			
			for(Account a : accounts) {
				if(a.getAccountNo().equals(accountNo)) {
					owner = a;
					break;
				}
			}
			
			if(owner != null) {
				owner.addTransaction(t);
			}
		}
		
		int max = 0;
		for(Transaction t : transactions) {
			if(t.getTransactionID() > max) {
				max = t.getTransactionID();
			}
		}
		
		Transaction.setCounter(max + 1);
		


	}
}
