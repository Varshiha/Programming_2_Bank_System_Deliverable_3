package application;
import java.util.ArrayList;

public abstract class Client {
	
	protected int clientID;
	protected String username;
	protected String password;
	public String type;
	protected ArrayList<Account> accounts;
	protected static int counter = 500;
	
	/*
	 Constructor
	 */
	public Client(String username, String password) {
		this.clientID = counter;
		counter += 5;
		this.username = username;
		this.password = password;
		this.accounts = new ArrayList<>();
	}
	
	public boolean hasChequingAccount() {
		for(Account a : accounts) {
			if(a instanceof ChequingAccount) {
				return true;
			}
		}
		return false;
	}
	
	public Account openAccount(String type) throws MissingChequingAccountException {
		Account newAccount = null;
		if(type.equalsIgnoreCase("Chequing")) {
			newAccount = new ChequingAccount(this);
		}else if(type.equalsIgnoreCase("Savings")) {
				if(!hasChequingAccount()) {
					throw new MissingChequingAccountException("Must have a chequing account first");
				}
				newAccount = new SavingsAccount(this);
		}else if(type.equalsIgnoreCase("Investment")) {
				if(!hasChequingAccount()) {
					throw new MissingChequingAccountException("Must have a chequing account first");
				}
				newAccount = new InvestmentAccount(this);
		}
		
		return newAccount;
	}
	
	public boolean deposit(String accountNo, double amount) {
		Account account = findAccount(accounts, 0, accountNo);
		if(account == null) {
			return false;
		}
		account.deposit(amount);
		return true;
	}
	
	public void withdraw(String accountNo, double amount) throws InsufficientFundsException {
		for(Account a : accounts) {
			if(a.getAccountNo().equalsIgnoreCase(accountNo)) {
				a.withdraw(amount);
				return;
			}
		}
	}
	 public void transfer(String fromAccNo, String toAccNo, double amount) throws Exception {
		 Account from = null;
		 Account to = null;
		 for(Account a : accounts) {
				if(a.getAccountNo().equals(fromAccNo)) {
					from = a;
				}
				if(a.getAccountNo().equals(toAccNo)) {
					to = a;
				}
			}
		 if(from == null || to == null) {
			 throw new IllegalArgumentException("One of the account were not selected");
		 }
		 if(from instanceof InvestmentAccount && to instanceof ChequingAccount) {
			 ((InvestmentAccount) from).transferToChequing((ChequingAccount) to,amount);
		 }else if(from instanceof InvestmentAccount && (to instanceof SavingsAccount || to instanceof InvestmentAccount)) {
			 throw new Exception("Investment account can only transfer to a Chequing account");
		 }else {
			 from.withdraw(amount);
			 to.deposit(amount);
		 }
	
		 
	 }
	 public void addAccount(Account a) {
			if(a != null) {
				accounts.add(a);
			}
		}
	 /*
	 ===========================================================================================================
	                                   RECURSION
	 ===========================================================================================================
	 */
	 public Account findAccount(ArrayList<Account> accounts, int index, String accountNo) {
		 if(index >= accounts.size()) {
			 return null;
		 }
		 
		 if(accounts.get(index).getAccountNo().equalsIgnoreCase(accountNo)) {
			 return accounts.get(index);
		 }
		 return findAccount(accounts, (index+1), accountNo);
	 }
	
	 /*
	 ===========================================================================================================
	                                   GETTERS
	 ===========================================================================================================
	 */
	 public String getType() {
			return type;
		}
	 public int getClientID() {
			return clientID;
		}
	 public String getUsername() {
			return username;
		}
	 public String getPassword() {
			return password;
		}
	 public ArrayList<Account> getAccounts() {
			return accounts;
		}
	 /*
	 ===========================================================================================================
	                                   SETTERS
	 ===========================================================================================================
	 */
	 public void setAccounts(ArrayList<Account> accounts) {
			this.accounts.clear(); 
			this.accounts.addAll(accounts);
		}
		 public void setClientID(int clientID) {
				this.clientID = clientID;
				
			 }

}
