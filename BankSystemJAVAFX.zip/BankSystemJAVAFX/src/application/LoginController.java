package application;

import java.io.IOException;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
public class LoginController {
	@FXML
	private TextField usernameField;
	@FXML
	private PasswordField passwordField;
	@FXML
	private Label messageLabel;
	@FXML
	private Button mainButton;
	/*
	 ===========================================================================================================
	                                 MAIN SCREEN
	 ===========================================================================================================
	 */
	@FXML
	private void goBackMain(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("Welcome.fxml"));
		Scene scene = new Scene(root,1000,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		stage.setScene(scene);
		stage.show();
	}
	/*
	 ===========================================================================================================
	                              GET CLIENT INFO THAT LOGGED IN AND DASHBOARD SCREEN
	 ===========================================================================================================
	 */
	@FXML
	private void enter(ActionEvent event) throws IOException, InsufficientFundsException {
		String user = usernameField.getText();
		String pass = passwordField.getText();
		
		GetCurrentClient.clients = FileManager.loadClients();
		GetCurrentClient.accounts = FileManager.loadAccounts(GetCurrentClient.clients);
		FileManager.loadTransactions(GetCurrentClient.accounts);
		
		
		boolean found = false;
		int clientid = 0;
		
		for(Client c : GetCurrentClient.clients) {
			if(c.getUsername().equals(user) && c.getPassword().equals(pass)) {
				found = true;
				GetCurrentClient.currentClient = c;
				clientid = c.getClientID();
				break;
			}
		}
		
		if(found) {
			GetCurrentClient.currentUsername = usernameField.getText();
			GetCurrentClient.currentClientID = clientid;
			messageLabel.setText("Login Succesfull");
			Parent root = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		}else {
			messageLabel.setText("Invalid username or password. Try again!");
		}
		
	}
	/*
	 ===========================================================================================================
	                                 SIGN UP SCREEN
	 ===========================================================================================================
	 */
	@FXML
	private void goBackSignUp(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("SignUp.fxml"));
		Scene scene = new Scene(root,1000,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		stage.setScene(scene);
		stage.show();
	}

}
