package application;

public class VIPClient extends PremiumClient{

	private double bonusInterest = 0.01;
	

	public VIPClient(String username, String password) {
		super(username, password);
		this.type = "VIP";
	}
	public double getBonusInterest() {
		return bonusInterest;
	}

}
